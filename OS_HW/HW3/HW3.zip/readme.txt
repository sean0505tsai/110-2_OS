108820018 電資三 蔡翔宇
Code 安裝與執行方式：
在bash shell中執行
Q9.26:
在終端機開啟question9_26資料夾
輸入 g++ q_9_26.cpp
輸入 ./a.out